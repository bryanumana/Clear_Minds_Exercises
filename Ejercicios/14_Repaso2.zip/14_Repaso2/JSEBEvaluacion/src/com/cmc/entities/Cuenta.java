package com.cmc.entities;

public class Cuenta {
	
}
