package com.cmc.entities;

public class TipoCuenta {
	
}
