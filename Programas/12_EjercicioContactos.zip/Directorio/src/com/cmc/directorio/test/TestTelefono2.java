package com.cmc.directorio.test;

import com.cmc.directorio.entidades.AdminTelefono;
import com.cmc.directorio.entidades.Telefono;

public class TestTelefono2 {

	public static void main(String[] args) {
		Telefono telef = new Telefono("movi", "098234234", 20);
		telef.imprimir();

		AdminTelefono admin = new AdminTelefono();

		admin.activarMensajeria(telef);
		telef.imprimir();
	}

}
