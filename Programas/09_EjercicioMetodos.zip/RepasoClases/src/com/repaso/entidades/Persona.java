package com.repaso.entidades;

public class Persona {

	private String nombre;
	private String apellido;
	private double estatura;
	private int codigo;

	public Persona() {

	}

	public Persona(String nombre, String apellido, double estatura, int codigo) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.estatura = estatura;
		this.codigo = codigo;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public double getEstatura() {
		return estatura;
	}

	public void setEstatura(double estatura) {
		this.estatura = estatura;
	}

	public int getCodigo() {
		return codigo;
	}

	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}

	public String getNombreCompleto() {
		return this.nombre + this.apellido;
	}

	public void agregarEstatura(double incremento) {
		double estaturaModificada;
		estaturaModificada = this.estatura + incremento;
		System.out.println("La estatura anterior es: " + this.estatura + "m " + "\n" + "El incremento es: " + incremento
				+ "m " + "\n" + "La esatura modificada es: " + estaturaModificada + "m " + "\n");
		this.estatura = estaturaModificada;
	}

	public void imprimir() {

		System.out.println("**********************************" + "\n" + "             PERSONA           " + "\n"
				+ "**********************************" + "\n" + "El codigo de la persona es: " + this.codigo + "\n"
				+ "El nombre de la persona es: " + this.nombre + "\n" + "El apellido de la persona es: " + this.apellido
				+ "\n" + "La estatura de la persona es:" + this.estatura + "m " + "\n"
				+ "**********************************" + "\n");
	}

	public double modificarEstatura(double incrmento) {
		System.out.println("La estatura anterior es: " + this.estatura + "\n" + "El incremento es: " + incrmento);
		return this.estatura + incrmento;
	}

	public String obtenerInformacion() {
		return "Codigo: " + this.codigo + " - " + "Nombre: " + this.nombre + " - " + "Apellido: " + this.apellido
				+ " - " + "Estatura: " + this.estatura + "m " + "\n";
	}

	public double cambiarValores(int nuevoCodigo, double incremento) {
		double estaturaModificada = this.estatura + incremento;
		this.codigo = nuevoCodigo;
		this.estatura = estaturaModificada;
		return nuevoCodigo+incremento;
	}

}
