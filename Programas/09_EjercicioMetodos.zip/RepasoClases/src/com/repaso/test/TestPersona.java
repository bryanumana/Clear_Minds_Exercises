package com.repaso.test;

import com.repaso.entidades.Persona;

public class TestPersona {

	public static void main(String[] args) {
		String nombreCompleto, obtenerInformacionCompleta;
		double modificarEstaturaDouble, suma;
		
		
		Persona p1 = new Persona();
		p1.setNombre("Borussia ");
		p1.setApellido("Dortmund");
		p1.setEstatura(1.68);
		p1.setCodigo(9);
		
		Persona p2 = new Persona();
		p2.setNombre("Bayern");
		p2.setApellido("Munchen");
		p2.setEstatura(1.75);
		p2.setCodigo(00);
		
		System.out.println("___getNombreCompleto___");
		nombreCompleto = p1.getNombreCompleto();
		System.out.print(nombreCompleto +"\n\n" );
		
		System.out.println("___agregarEstatura___");
		p1.agregarEstatura(0.04);
		
		
		System.out.println("___imprimir___");
		p1.imprimir();

		System.out.println("___modificarEstatura___");
		modificarEstaturaDouble = p2.modificarEstatura(0.04);
		System.out.println("la estatura modificada es: " + modificarEstaturaDouble + "m "+ "\n");
		p2.setEstatura(modificarEstaturaDouble);
		
		System.out.println("___obtenerInfromacion___");
		obtenerInformacionCompleta = p2.obtenerInformacion();
		System.out.println(obtenerInformacionCompleta +"\n");
		
		System.out.println("___cambiarValores___");
		suma = p2.cambiarValores(5, 0.13);
		System.out.println("La estatura modificada es: " + p2.getEstatura()  +"m " +"\n"
				+ "El nuevo codigo es: " + p2.getCodigo() + "\n" +
				"La suma es: " + suma);
	}
}
